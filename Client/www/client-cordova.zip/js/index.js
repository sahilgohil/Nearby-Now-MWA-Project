document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {

    $.ajaxSetup({
        crossDomain: true,
        xhrFields: {
            withCredentials: true
        }
    });

    $("#login-error").hide();
    $("#sign-up-error").hide();


    // handle the user login request
    $("#login-form").on("submit", (e) => {
        e.preventDefault();
        let error = "";
        const { usernamel, passwordl } = e.target;
        if (!usernamel.value) {
            error = "Username is required";
            $("#login-error").text(error);
            $("#login-error").show();
        } else if (!passwordl.value) {
            $("#login-error").text(error);
            $("#login-error").show();
            error = "Password is required";
        } else {
            $.post('http://localhost:3000/loginUser',{"username":usernamel.value,"password":passwordl.value},(reply,status)=>{
                if(reply.authentication === 'success')
                {
                    $("#user-heading").text(`Welcome to you home ${reply.firstname},`)
                    $.mobile.changePage("#dashboard", {
                        transition: "slide"
                    });
                }
                else{
                    alert(reply.message);
                }
                
            })
        }
    });


    // handle the user sign up request
    $("#sign-up-form").on("submit", (e) => {
        e.preventDefault();
        let error = "";
        const { firstname, lastname, username, password, c_password } = e.target;
        if (password.value !== c_password.value) {
            
            error = "Passwords are not matching!";
            $("#sign-up-error").text(error);
            $("#sign-up-error").show();
        }
        else{
            $("#sign-up-error").hide();
            const user = {
                "firstname":firstname.value,
                "lastname":lastname.value,
                "username":username.value,
                "password":password.value
            }
            $.post('http://localhost:3000/createNewUser',{
                "firstname":firstname.value,
                "lastname":lastname.value,
                "username":username.value,
                "password":password.value
            },(reply,status)=>{
                $("#user-heading").text(`Welcome to you home ${firstname},`)
                $.mobile.changePage("#home",{
                    transition:'slide'
                })
            })
        
            
        }
    });



    // handle the user logout
    $('#logout').click(()=>{
        $.get('http://localhost:3000/logout',(reply,status)=>{
            alert(reply.message);
            $.mobile.changePage("#home",{
                transition:'slide'
            })
        })
    })


    $('#restaurant-btn').click(()=>{

        // checking if the geo location is available
        if(navigator.geolocation)
        {
            navigator.geolocation.getCurrentPosition((p)=>{
                const lattitude = p.coords.latitude;
                const longitude = p.coords.longitude;
                $.post('http://localhost:3000/getNearbyPlace',{"lat":lattitude,"lon":longitude,"place":"restaurant"},(reply,status)=>{
                    alert(reply.message);
                    console.log(reply.data);
                })
            },(err)=>{
                console.log(err);
            })
        }
    })

    $('#shoppingmall-btn').click(()=>{

        // checking if the geo location is available
        if(navigator.geolocation)
        {
            navigator.geolocation.getCurrentPosition((p)=>{
                const lattitude = p.coords.latitude;
                const longitude = p.coords.longitude;
                $.post('http://localhost:3000/getNearbyPlace',{"lat":lattitude,"lon":longitude,"place":"shopping_mall"},(reply,status)=>{
                    alert(reply.message);
                    console.log(reply.data);
                })
            },(err)=>{
                console.log(err);
            })
        }
    })

    // handle park requests 
    $('#park-btn').click(()=>{

        // checking if the geo location is available
        if(navigator.geolocation)
        {
            navigator.geolocation.getCurrentPosition((p)=>{
                const lattitude = p.coords.latitude;
                const longitude = p.coords.longitude;
                $.post('http://localhost:3000/getNearbyPlace',{"lat":lattitude,"lon":longitude,"place":"park"},(reply,status)=>{
                    alert(reply.message);
                    console.log(reply.data);
                })
            },(err)=>{
                console.log(err);
            })
        }
    })

    // handle the gym requests
    $('#gym-btn').click(()=>{

        // checking if the geo location is available
        if(navigator.geolocation)
        {
            navigator.geolocation.getCurrentPosition((p)=>{
                const lattitude = p.coords.latitude;
                const longitude = p.coords.longitude;
                $.post('http://localhost:3000/getNearbyPlace',{"lat":lattitude,"lon":longitude,"place":"gym"},(reply,status)=>{
                    alert(reply.message);
                    console.log(reply.data);
                })
            },(err)=>{
                console.log(err);
            })
        }
    })

    $('#library-btn').click(()=>{

        // checking if the geo location is available
        if(navigator.geolocation)
        {
            navigator.geolocation.getCurrentPosition((p)=>{
                const lattitude = p.coords.latitude;
                const longitude = p.coords.longitude;
                $.post('http://localhost:3000/getNearbyPlace',{"lat":lattitude,"lon":longitude,"place":"library"},(reply,status)=>{
                    alert(reply.message);
                    console.log(reply.data);
                })
            },(err)=>{
                console.log(err);
            })
        }
    })
}
